
SoPh.I.A. - Projeto Flutter (pronto para compilar)

Conteúdo:
- lib/main.dart
- lib/chat_screen.dart
- lib/services/tts_service.dart
- lib/services/stt_service.dart
- lib/services/ai_service.dart
- pubspec.yaml

Funcionalidades implementadas:
- Chat de texto
- Entrada por voz (microfone) usando speech_to_text
- Leitura das respostas (TTS) usando flutter_tts
- Envio de arquivos (file_picker) - o arquivo é apenas reconhecido, não enviado a servidor
- Tema escuro preto/branco
- IA simulada local (AIService)

Permissões Android:
- speech_to_text e file picker exigem permissões em AndroidManifest.xml. Ao compilar, verifique:
  android/app/src/main/AndroidManifest.xml
  Adicione dentro de <manifest>:
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>

Como compilar (passo a passo)
1) Instale o Flutter SDK: https://docs.flutter.dev/get-started/install
   - Siga as instruções para seu sistema operacional (Windows, macOS, Linux).
   - Configure o Android SDK e adicione o `flutter` ao PATH.
2) Abra terminal (ou PowerShell no Windows) e navegue até a pasta do projeto (onde está este README).
   Exemplo:
     cd /caminho/para/sophia_project
3) Rode:
     flutter pub get
4) Conecte seu dispositivo Android por USB (com depuração USB habilitada) ou inicie um emulador Android.
5) Para testar em modo debug:
     flutter run
6) Para gerar o APK release:
     flutter build apk --release
   - O APK final ficará em:
     build/app/outputs/flutter-apk/app-release.apk
7) Para instalar no seu celular via adb:
     adb install -r build/app/outputs/flutter-apk/app-release.apk

Integração com OpenAI (opcional)
- Se quiser integrar com OpenAI, eu adiciono a chamada HTTP e instruções de onde colar sua chave.
- Por segurança, não coloque a chave diretamente no código — use variáveis de ambiente ou SharedPreferences criptografado.

Observações finais:
- Projeto entregue para uso pessoal e não comercial.
- Se quiser que eu exporte para FlutterFlow (.ffapp) ou que eu adicione integração com OpenAI agora, diga e eu ajusto.
