// Copyright © Pedro Henrique. Uso pessoal e não comercial.
// SoPh.I.A. - main.dart
import 'package:flutter/material.dart';
import 'chat_screen.dart';

void main() => runApp(const SophiaApp());

class SophiaApp extends StatelessWidget {
  const SophiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SoPh.I.A.',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.white)),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
      ),
      home: const ChatScreen(),
    );
  }
}
