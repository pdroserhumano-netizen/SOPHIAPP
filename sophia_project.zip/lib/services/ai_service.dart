class AIService {
  // Simulated responses; replace with real API integration later if desired.
  String generateResponse(String input) {
    final query = input.toLowerCase();
    if (query.contains('olá') || query.contains('oi')) {
      return 'Olá — sou SoPh.I.A. Como você está hoje?';
    }
    if (query.contains('ajuda') || query.contains('preciso')) {
      return 'Vamos por partes. Me diga, qual é a parte mais urgente?';
    }
    if (query.contains('senha') || query.contains('dinheiro')) {
      return 'Lembre-se de não compartilhar senhas ou dados sensíveis aqui.';
    }
    if (query.contains('?')) {
      return 'Pergunta interessante. O que você já tentou até agora?';
    }
    return 'Interessante... conte-me mais sobre isso.';
  }
}
