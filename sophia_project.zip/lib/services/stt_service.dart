import 'package:speech_to_text/speech_to_text.dart';

class STTService {
  final SpeechToText _speech = SpeechToText();

  Future<void> startListening({required Function(String) onResult}) async {
    final available = await _speech.initialize();
    if (!available) return;
    _speech.listen(onResult: (result) {
      onResult(result.recognizedWords);
    });
  }

  Future<String> stopListening() async {
    try {
      await _speech.stop();
    } catch (e) {}
    return "";
  }
}
