// Chat UI + integration with services
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'services/tts_service.dart';
import 'services/stt_service.dart';
import 'services/ai_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  final TTSService tts = TTSService();
  final STTService stt = STTService();
  final AIService ai = AIService();

  bool listening = false;
  String topName = 'SoPh.I.A.';

  @override
  void initState() {
    super.initState();
    _loadName();
  }

  Future<void> _loadName() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('app_name');
    if (saved != null && saved.isNotEmpty) {
      setState(() => topName = saved);
    } else {
      await prefs.setString('app_name', topName);
    }
  }

  void _sendMessage(String text) {
    final t = text.trim();
    if (t.isEmpty) return;
    setState(() {
      _messages.add({'from': 'user', 'text': t});
    });
    _controller.clear();
    final reply = ai.generateResponse(t);
    Future.delayed(const Duration(milliseconds: 400), () {
      setState(() {
        _messages.add({'from': 'assistant', 'text': reply});
      });
      tts.speak(reply);
    });
  }

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.any);
      if (result != null && result.files.isNotEmpty) {
        final name = result.files.first.name;
        setState(() {
          _messages.add({'from': 'user', 'text': '[arquivo enviado] ' + name});
        });
        // AI can respond acknowledging file
        final reply = ai.generateResponse('O usuário enviou um arquivo: ' + name);
        setState(() => _messages.add({'from': 'assistant', 'text': reply}));
        tts.speak(reply);
      }
    } catch (e) {
      setState(() => _messages.add({'from': 'assistant', 'text': 'Erro ao selecionar arquivo.'}));
    }
  }

  Future<void> _toggleListening() async {
    if (listening) {
      final result = await stt.stopListening();
      if (result.isNotEmpty) _sendMessage(result);
    } else {
      await stt.startListening(onResult: (text) {
        setState(() => _controller.text = text);
      });
    }
    setState(() => listening = !listening);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(topName, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: false,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final msg = _messages[i];
                final isUser = msg['from'] == 'user';
                final text = msg['text'] ?? '';
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    mainAxisAlignment:
                        isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
                    children: [
                      if (!isUser)
                        Container(
                          margin: const EdgeInsets.only(right: 8),
                          child: CircleAvatar(
                            radius: 18,
                            backgroundColor: Colors.white,
                            child: Icon(Icons.person, color: Colors.black),
                          ),
                        ),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            text,
                            style: const TextStyle(color: Colors.black),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            color: Colors.black,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(listening ? Icons.mic_off : Icons.mic, color: Colors.white),
                  onPressed: _toggleListening,
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Fale ou digite...',
                      hintStyle: TextStyle(color: Colors.white54),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (v) => _sendMessage(v),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.attach_file, color: Colors.white),
                  onPressed: _pickFile,
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.white),
                  onPressed: () => _sendMessage(_controller.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
